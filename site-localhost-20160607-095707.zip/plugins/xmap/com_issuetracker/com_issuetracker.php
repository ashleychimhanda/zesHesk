<?php
/**
 *
 * Issuetracker
 * XMAP plugin
 *
 * @Version       $Id: com_issuetracker.php 2066 2015-08-25 14:34:57Z geoffc $
 * @Package       Issue Tracker
 * @Subpackage    com_issuetracker
 * @Release       1.7.0
 * @Copyright     Copyright (C) 2015 Macrotone Consulting Ltd. All rights reserved.
 * @License       GNU General Public License version 3 or later; see LICENSE.txt
 * @Contact       support@macrotoneconsulting.co.uk
 * @Lastrevision  $Date: 2015-08-25 15:34:57 +0100 (Tue, 25 Aug 2015) $
 *
*/

defined('_JEXEC') or die('Restricted Access');

if (! class_exists('IssuetrackerHelperLog')) {
   require_once( JPATH_ADMINISTRATOR.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_issuetracker'.DIRECTORY_SEPARATOR.'helpers'.DIRECTORY_SEPARATOR.'log.php');
}

/**
 * Class xmap_com_issuetracker
 */
class xmap_com_issuetracker
{
   /**
    * @var array
    */
   private static $views = array('itprojectslist', 'itissueslist', 'itpeoplelist');

   /**
    * @var bool
    */
   private static $enabled = false;

   /**
    *
    */
   public function __construct()
   {
      self::$enabled = JComponentHelper::isEnabled('com_issuetracker');
   }

   /**
    * PrepareMenuItem
    *
    * @param $node
    * @param $params
    */
   function prepareMenuItem($node, &$params)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - prepareMenuItem ', JLog::DEBUG);
      $db = JFactory::getDbo();
      $link_query = parse_url($node->link);
      if (!isset($link_query['query'])) {
         return;
      }

      $node->modified = isset($node->modified) ? $node->modified  : time();
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    */
   public static function getTree($xmap, stdClass $parent, array &$params)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getTree ', JLog::DEBUG);
      $uri = new JUri($parent->link);

      if (!self::$enabled || !in_array($uri->getVar('view'), self::$views)) {
         return;
      }

      $params['include_issues'] = JArrayHelper::getValue($params, 'include_issues', 1);
      $params['include_issues'] = ($params['include_issues'] == 1 || ($params['include_issues'] == 2 && $xmap->view == 'xml') || ($params['include_issues'] == 3 && $xmap->view == 'html'));

      $params['include_expired_issues'] = JArrayHelper::getValue($params, 'include_expired_issues', 0);
      $params['include_expired_issues'] = ($params['include_expired_issues'] == 1 || ($params['include_expired_issues'] == 2 && $xmap->view == 'xml') || ($params['include_expired_issues'] == 3 && $xmap->view == 'html'));

      $params['project_priority'] = JArrayHelper::getValue($params, 'project_priority', $parent->priority);
      $params['project_changefreq'] = JArrayHelper::getValue($params, 'project_changefreq', $parent->changefreq);

      if ($params['project_priority'] == -1) {
         $params['project_priority'] = $parent->priority;
      }

      if ($params['project_changefreq'] == -1) {
         $params['project_changefreq'] = $parent->changefreq;
      }

      $params['issue_priority'] = JArrayHelper::getValue($params, 'issue_priority', $parent->priority);
      $params['issue_changefreq'] = JArrayHelper::getValue($params, 'issue_changefreq', $parent->changefreq);

      if ($params['issue_priority'] == -1) {
         $params['issue_priority'] = $parent->priority;
      }

      if ($params['issue_changefreq'] == -1) {
         $params['issue_changefreq'] = $parent->changefreq;
      }

      $params['limit'] = '';
      $limit = JArrayHelper::getValue($params, 'max_links', '');
      if (intval($limit))
         $params['limit'] = $limit;

      switch ($uri->getVar('view')) {
         case 'itprojectslist':
            self::getProjectTree($xmap, $parent, $params, 1);
            break;
         case 'itissueslist':
            // self::getIssues($xmap, $parent, $params, 1);
            self::getCategoryTree($xmap, $parent, $params, 1);
            break;
         case 'itpeoplelist':
            self::getPeopleTree($xmap, $parent, $params, 1);
            break;
         case 'itissues':
            self::getIssue($xmap, $parent, $params, $uri->getVar('id'));
            break;
         case 'itprojects':
            self::getProject($xmap, $parent, $params, $uri->getVar('id'));
            break;
         case 'itpeople':
            self::getPeople($xmap, $parent, $params, $uri->getVar('id'));
            break;
      }
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param int $parent_id
    */
   private static function getProjectTree($xmap, stdClass $parent, array &$params, $parent_id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getProjectTree ', JLog::DEBUG);
      // Get menu projects in list
      $pids = $parent->params['project_ids'];

      $db = JFactory::getDbo();
      $query = $db->getQuery(true)
         ->select(array('id', 'title'))
         ->from('#__it_projects')
         ->where('parent_id > 0')
         ->where('state = 1');

      if ( ! empty($pids) && $pids[0] != 0 )
         $query->where(" id IN ('".implode("','",$pids)."')");

      $query->order('lft ASC');

      // if ( !empty($params['limit']) )
      //   $query->setLimit($params['limit']);

      // IssuetrackerHelperLog::dblog('XMAP plugin - getProjectTree query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->title;
         $node->uid = $parent->uid . '_cid_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['project_priority'];
         $node->changefreq = $params['project_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itprojects&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getProjectTree link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param int $parent_id
    */
   private static function getCategoryTree($xmap, stdClass $parent, array &$params, $parent_id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getCategoryTree ', JLog::DEBUG);
      // Get menu projects in list
      $pids = $parent->params['project_ids'];

      $db = JFactory::getDbo();
      $query = $db->getQuery(true)
         ->select(array('id', 'title', 'level'))
         ->from('#__it_projects')
         ->where('parent_id > 0')
//         ->where('parent_id = ' . $db->quote($parent_id))
         ->where('state = 1');

      if ( ! empty($pids) && $pids[0] != 0 )
         $query->where(" id IN ('".implode("','",$pids)."')");

      $query->order('lft ASC');

      // if ( !empty($params['limit']) )
      //   $query->setLimit($params['limit']);

      // IssuetrackerHelperLog::dblog('XMAP plugin - getCategoryTree query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
//         if ( $row->level > 1) {
//            $xmap->changeLevel(1);
//         }
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->title;
         $node->uid = $parent->uid . '_cid_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['project_priority'];
         $node->changefreq = $params['project_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itissueslist&pid=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getCategoryTree link '.$node->link, JLog::DEBUG);

         if ($xmap->printNode($node) !== false) {
            self::getIssues($xmap, $parent, $params, $row->id);
         }
//         if ( $row->level > 1) {
//            $xmap->changeLevel(-1);
//         }

      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param $catid
    */
   private static function getIssues($xmap, stdClass $parent, array &$params, $catid)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getIssues - category id: '.$catid, JLog::DEBUG);
      $pids = $parent->params['project_ids'];
      $sids = $parent->params['status_ids'];

      // self::getCategoryTree($xmap, $parent, $params, $catid);

      if (!$params['include_issues']) {
         return;
      }

      $db   = JFactory::getDbo();
      $now  = JFactory::getDate('now', 'UTC')->toSql();

      $query = $db->getQuery(true)
         ->select(array('a.id', 'a.issue_summary'))
         ->from('#__it_issues AS a')
         ->join('INNER', '#__it_projects AS c ON (c.id = a.related_project_id)')
         ->where('c.id = ' . $db->Quote($catid));

      if ( ! empty($pids) && $pids[0] != 0 )
         $query->where(" a.related_project_id IN ('".implode("','",$pids)."')");
      if ( ! empty($sids) && $sids[0] != 0 )
         $query->where(" a.status IN ('".implode("','",$sids)."')");

      $query->order('a.id');

/*
      if ($params['include_expired_issues']) {
         $query->where('a.date_created <= ' . $db->quote($now));
         $query->where('a.state IN (0,1) ');
      } else {
*/
         $query->where('a.state = 1 ');
//      }

      if ( !empty($params['limit']) )
         $query->setLimit($params['limit']);

      // IssuetrackerHelperLog::dblog('XMAP plugin - getIssues query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      if (empty($rows)) {
         // IssuetrackerHelperLog::dblog('XMAP plugin - getIssues row - no issues found!', JLog::DEBUG);
         return;
      }

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->issue_summary;
         $node->uid = $parent->uid . '_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['issue_priority'];
         $node->changefreq = $params['issue_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itissues&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getIssues link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param $id
    */
   private static function getIssue($xmap, stdClass $parent, array &$params, $id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getIssue ', JLog::DEBUG);

      $db   = JFactory::getDbo();
      $now  = JFactory::getDate('now', 'UTC')->toSql();

      $query = $db->getQuery(true)
         ->select(array('a.id', 'a.issue_summary'))
         ->from('#__it_issues AS a')
         ->join('INNER', '#__it_projects AS c ON (c.id = a.related_project_id)')
         ->where('a.id = ' . $db->Quote($id))
         ->where('a.state = 1 ');

      // IssuetrackerHelperLog::dblog('XMAP plugin - getIssue query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      if (empty($rows)) {
         // IssuetrackerHelperLog::dblog('XMAP plugin - getIssue row - no issue found!', JLog::DEBUG);
         return;
      }

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->issue_summary;
         $node->uid = $parent->uid . '_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['issue_priority'];
         $node->changefreq = $params['issue_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itissues&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getIssue link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param int $parent_id
    */
   private static function getPeopleTree($xmap, stdClass $parent, array &$params, $parent_id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getPeopleTree ', JLog::DEBUG);
      $db = JFactory::getDbo();
      $query = $db->getQuery(true)
         ->select('id, person_name')
         ->from('#__it_people')
         ->where('published = 1')
         ->order('person_name ASC');

      if ( !empty($params['limit']) )
         $query->setLimit($params['limit']);

      // IssuetrackerHelperLog::dblog('XMAP plugin - getPeopleTree query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->person_name;
         $node->uid = $parent->uid . '_cid_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['project_priority'];
         $node->changefreq = $params['project_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itpeople&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getPeopleTree link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param $id
    */
   private static function getPerson($xmap, stdClass $parent, array &$params, $id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getPerson ', JLog::DEBUG);

      $db   = JFactory::getDbo();
      $now  = JFactory::getDate('now', 'UTC')->toSql();

      $query = $db->getQuery(true)
         ->select(array('id', 'person_name'))
         ->from('#__it_people')
         ->where('id = ' . $db->Quote($id))
         ->where('published = 1 ');

      // IssuetrackerHelperLog::dblog('XMAP plugin - getPerson query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      if (empty($rows)) {
         // IssuetrackerHelperLog::dblog('XMAP plugin - getPerson row - no person found!', JLog::DEBUG);
         return;
      }

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->person_name;
         $node->uid = $parent->uid . '_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['issue_priority'];
         $node->changefreq = $params['issue_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itpeople&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getPerson link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

   /**
    * @param XmapDisplayerInterface $xmap
    * @param stdClass $parent
    * @param array $params
    * @param $id
    */
   private static function getProject($xmap, stdClass $parent, array &$params, $id)
   {
      // IssuetrackerHelperLog::dblog('XMAP plugin - getProject ', JLog::DEBUG);

      $db   = JFactory::getDbo();
      $now  = JFactory::getDate('now', 'UTC')->toSql();

      $query = $db->getQuery(true)
         ->select(array('id', 'title'))
         ->from('#__it_projects')
         ->where('id = ' . $db->Quote($id))
         ->where('state = 1');

      // IssuetrackerHelperLog::dblog('XMAP plugin - getProject query '.$query, JLog::DEBUG);

      $db->setQuery($query);
      $rows = $db->loadObjectList();

      if (empty($rows)) {
         // IssuetrackerHelperLog::dblog('XMAP plugin - getProject row - no project found!', JLog::DEBUG);
         return;
      }

      $xmap->changeLevel(1);

      foreach ($rows as $row) {
         $node = new stdclass;
         $node->id = $parent->id;
         $node->name = $row->title;
         $node->uid = $parent->uid . '_' . $row->id;
         $node->browserNav = $parent->browserNav;
         $node->priority = $params['issue_priority'];
         $node->changefreq = $params['issue_changefreq'];
         $node->link = JRoute::_('index.php?option=com_issuetracker&view=itprojects&id=' . $row->id . '&Itemid=' . $parent->id);

         // IssuetrackerHelperLog::dblog('XMAP plugin - getProject link '.$node->link, JLog::DEBUG);

         $xmap->printNode($node);
      }

      $xmap->changeLevel(-1);
   }

}